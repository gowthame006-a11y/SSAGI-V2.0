export interface LawReference {
  code: string;
  title: string;
  description: string;
  severity: "critical" | "warning" | "info";
}

export interface ReasoningItem {
  label: string;
  description: string;
  impact: number; // 0-1
}

export interface AgentResult {
  agent: string;
  category: string;
  score: number;
  message: string;
  details: string[];
  icon: string;
  reasoning: ReasoningItem[];
  laws: LawReference[];
  recommendation: string;
}

export interface EvaluationResult {
  id: string;
  timestamp: string;
  input: string;
  decision: "BLOCKED" | "REVIEW_REQUIRED" | "APPROVED";
  overallScore: number;
  agents: AgentResult[];
  summary: string;
}
