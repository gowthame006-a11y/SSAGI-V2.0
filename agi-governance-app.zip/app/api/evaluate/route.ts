import { NextResponse } from "next/server";

interface LawReference {
  code: string;
  title: string;
  description: string;
  severity: "critical" | "warning" | "info";
}

interface ReasoningItem {
  label: string;
  description: string;
  impact: number;
}

interface AgentResult {
  agent: string;
  category: string;
  score: number;
  message: string;
  details: string[];
  icon: string;
  reasoning: ReasoningItem[];
  laws: LawReference[];
  recommendation: string;
}

interface EvaluationResult {
  id: string;
  timestamp: string;
  input: string;
  decision: "BLOCKED" | "REVIEW_REQUIRED" | "APPROVED";
  overallScore: number;
  agents: AgentResult[];
  summary: string;
}

// ============================================
// Psychology Agent
// ============================================
function runPsychologyAgent(text: string): AgentResult {
  const lowerText = text.toLowerCase();
  const details: string[] = [];
  const reasoning: ReasoningItem[] = [];
  const laws: LawReference[] = [];
  let score = 0;

  const highRiskWords = ["hate", "angry", "revenge", "rage", "fury", "hostile", "violent", "destroy"];
  const medRiskWords = ["upset", "frustrated", "annoyed", "irritated", "anxious", "worried", "fear"];
  const positiveWords = ["happy", "love", "kind", "help", "support", "care", "peace", "joy"];

  const highMatches = highRiskWords.filter((w) => lowerText.includes(w));
  const medMatches = medRiskWords.filter((w) => lowerText.includes(w));
  const posMatches = positiveWords.filter((w) => lowerText.includes(w));

  if (highMatches.length > 0) {
    score += 0.35 * highMatches.length;
    details.push(`High-risk emotional markers detected: ${highMatches.join(", ")}`);
    reasoning.push({
      label: "Aggressive Emotional Markers",
      description: `The input contains ${highMatches.length} high-risk emotional term(s): "${highMatches.join('", "')}". These words indicate potential hostile intent or emotional distress that could escalate to harmful behavior.`,
      impact: Math.min(0.35 * highMatches.length, 1),
    });
    laws.push({
      code: "APA-ETH-3.04",
      title: "APA Ethical Principles - Harm Prevention",
      description: "Psychologists take reasonable steps to avoid harming others and to minimize harm where it is foreseeable and unavoidable.",
      severity: "critical",
    });
  }

  if (medMatches.length > 0) {
    score += 0.15 * medMatches.length;
    details.push(`Moderate emotional indicators found: ${medMatches.join(", ")}`);
    reasoning.push({
      label: "Moderate Emotional Distress",
      description: `Detected ${medMatches.length} moderate emotional indicator(s): "${medMatches.join('", "')}". These suggest underlying distress that warrants monitoring but not immediate intervention.`,
      impact: Math.min(0.15 * medMatches.length, 1),
    });
  }

  if (posMatches.length > 0) {
    score -= 0.1 * posMatches.length;
    details.push(`Positive sentiment detected: ${posMatches.join(", ")}`);
    reasoning.push({
      label: "Positive Sentiment Offset",
      description: `Found ${posMatches.length} positive emotional marker(s): "${posMatches.join('", "')}". These reduce the overall risk profile by indicating constructive emotional tone.`,
      impact: 0,
    });
  }

  // Intent analysis
  const intentPatterns = ["want to", "going to", "plan to", "will", "need to"];
  const intentMatches = intentPatterns.filter((p) => lowerText.includes(p));
  if (intentMatches.length > 0 && highMatches.length > 0) {
    score += 0.2;
    details.push("Strong intent combined with negative emotion detected");
    reasoning.push({
      label: "Intent-Emotion Correlation",
      description: "Active intent language combined with negative emotional markers creates a compound risk. The user expresses both emotional distress and a clear desire to act, suggesting elevated probability of harmful behavior.",
      impact: 0.2,
    });
    laws.push({
      code: "WHO-MH-2019",
      title: "WHO Mental Health Action Plan",
      description: "Early identification of psychological distress with active intent is critical for preventive intervention per WHO guidelines.",
      severity: "warning",
    });
  }

  // Manipulation detection
  const manipulationWords = ["pretend", "trick", "deceive", "manipulate", "exploit", "convince them to"];
  const manipMatches = manipulationWords.filter((w) => lowerText.includes(w));
  if (manipMatches.length > 0) {
    score += 0.25 * manipMatches.length;
    details.push(`Manipulation indicators: ${manipMatches.join(", ")}`);
    reasoning.push({
      label: "Manipulation Indicators",
      description: `Detected ${manipMatches.length} manipulation-related term(s): "${manipMatches.join('", "')}". These suggest the user may be seeking to psychologically exploit others, posing a significant ethical concern.`,
      impact: Math.min(0.25 * manipMatches.length, 1),
    });
    laws.push({
      code: "EU-AI-ACT-5",
      title: "EU AI Act - Article 5 (Prohibited Practices)",
      description: "AI systems that deploy subliminal, manipulative, or deceptive techniques to distort behavior are prohibited under the EU AI Act.",
      severity: "critical",
    });
  }

  score = Math.max(0, Math.min(1, score));

  if (reasoning.length === 0) {
    reasoning.push({
      label: "Baseline Emotional Assessment",
      description: "The input text shows a neutral emotional profile with no indicators of distress, hostility, or manipulation. The psychological risk is minimal.",
      impact: 0,
    });
  }

  if (laws.length === 0) {
    laws.push({
      code: "APA-ETH-1.01",
      title: "APA General Applicability",
      description: "Standard ethical guidelines apply. No specific psychological risk concerns warrant elevated regulatory attention.",
      severity: "info",
    });
  }

  const recommendation =
    score > 0.5
      ? "Immediate review by a mental health professional is recommended. Flag content for human oversight and consider restricting automated response."
      : score > 0.2
        ? "Monitor for escalation. Apply standard emotional safety checks before generating any response."
        : "No psychological concerns. Safe to proceed with standard processing.";

  return {
    agent: "Psychology Agent",
    category: "Emotion & Intent",
    score: Math.round(score * 100) / 100,
    message: score > 0.5 ? "Elevated emotional risk detected" : "Emotional profile within safe parameters",
    details,
    icon: "brain",
    reasoning,
    laws,
    recommendation,
  };
}

// ============================================
// Neuroscience Agent
// ============================================
function runNeuroscienceAgent(text: string): AgentResult {
  const details: string[] = [];
  const reasoning: ReasoningItem[] = [];
  const laws: LawReference[] = [];
  let score = 0;

  const words = text.split(/\s+/).filter(Boolean);
  const wordCount = words.length;
  const avgWordLength = words.reduce((sum, w) => sum + w.length, 0) / (wordCount || 1);
  const sentenceCount = text.split(/[.!?]+/).filter(Boolean).length;
  const avgWordsPerSentence = wordCount / (sentenceCount || 1);

  const complexityScore = Math.min((avgWordLength - 3) / 7, 1);
  const verbosityScore = Math.min(wordCount / 200, 1);
  const sentenceComplexity = Math.min(avgWordsPerSentence / 30, 1);

  score = complexityScore * 0.3 + verbosityScore * 0.4 + sentenceComplexity * 0.3;

  details.push(`Word count: ${wordCount} | Avg word length: ${avgWordLength.toFixed(1)}`);
  details.push(`Sentence complexity index: ${(sentenceComplexity * 100).toFixed(0)}%`);
  details.push(`Cognitive load estimation: ${(score * 100).toFixed(0)}%`);

  reasoning.push({
    label: "Linguistic Complexity Analysis",
    description: `Input contains ${wordCount} words with average length of ${avgWordLength.toFixed(1)} characters across ${sentenceCount} sentence(s). Average of ${avgWordsPerSentence.toFixed(1)} words per sentence. Higher complexity correlates with increased cognitive load on AI processing systems.`,
    impact: complexityScore,
  });

  reasoning.push({
    label: "Verbosity Assessment",
    description: `The input length is ${wordCount}/200 words relative to standard evaluation threshold. ${wordCount > 100 ? "Extended inputs increase the surface area for hidden adversarial content and cognitive overload exploits." : "Input length is within normal parameters for safe processing."}`,
    impact: verbosityScore,
  });

  reasoning.push({
    label: "Sentence Structure Evaluation",
    description: `Sentence complexity index is ${(sentenceComplexity * 100).toFixed(0)}%. ${avgWordsPerSentence > 20 ? "Long, complex sentences may contain obfuscated requests or nested harmful directives." : "Sentence structure is clear and well-formed, reducing risk of obfuscated intent."}`,
    impact: sentenceComplexity,
  });

  // Pattern detection
  const repetitions = new Set(words.map((w) => w.toLowerCase()));
  const repetitionRatio = repetitions.size / (wordCount || 1);
  if (repetitionRatio < 0.5 && wordCount > 10) {
    score += 0.15;
    details.push("High word repetition detected - possible cognitive fixation");
    reasoning.push({
      label: "Repetition Pattern Anomaly",
      description: `Vocabulary diversity ratio is ${(repetitionRatio * 100).toFixed(0)}% (threshold: 50%). High repetition suggests cognitive fixation, automated generation, or deliberate obfuscation techniques.`,
      impact: 0.15,
    });
    laws.push({
      code: "NIST-AI-600-1",
      title: "NIST AI RMF - Cognitive Security",
      description: "Repetitive pattern injection is a known attack vector that can bypass AI safety measures through cognitive flooding.",
      severity: "warning",
    });
  }

  // Technical complexity
  const technicalTerms = ["algorithm", "protocol", "encryption", "database", "quantum", "neural", "binary"];
  const techMatches = technicalTerms.filter((t) => text.toLowerCase().includes(t));
  if (techMatches.length > 2) {
    score += 0.1;
    details.push(`Technical complexity elevated: ${techMatches.join(", ")}`);
    reasoning.push({
      label: "Technical Language Density",
      description: `Detected ${techMatches.length} technical terms: "${techMatches.join('", "')}". High density of technical vocabulary may indicate attempts to probe AI system capabilities or extract specialized knowledge.`,
      impact: 0.1,
    });
  }

  score = Math.max(0, Math.min(1, score));

  if (laws.length === 0) {
    laws.push({
      code: "ISO-24028",
      title: "ISO/IEC 24028 - AI Bias & Robustness",
      description: "Standard cognitive load metrics are within acceptable parameters for robust AI processing.",
      severity: "info",
    });
  }

  const recommendation =
    score > 0.6
      ? "Input shows high cognitive complexity. Apply additional parsing safeguards and consider chunked evaluation to prevent cognitive overflow attacks."
      : score > 0.3
        ? "Moderate cognitive load detected. Standard safety measures are sufficient but monitor for pattern escalation."
        : "Cognitive profile is nominal. No additional processing safeguards needed.";

  return {
    agent: "Neuroscience Agent",
    category: "Cognitive Analysis",
    score: Math.round(score * 100) / 100,
    message: score > 0.6 ? "High cognitive load detected" : "Cognitive profile nominal",
    details,
    icon: "zap",
    reasoning,
    laws,
    recommendation,
  };
}

// ============================================
// Legal Agent
// ============================================
function runLegalAgent(text: string): AgentResult {
  const lowerText = text.toLowerCase();
  const details: string[] = [];
  const reasoning: ReasoningItem[] = [];
  const laws: LawReference[] = [];
  let score = 0;

  const severeIllegal = ["kill", "murder", "assassinate", "bomb", "terrorize", "kidnap"];
  const moderateIllegal = ["fraud", "steal", "hack", "counterfeit", "launder", "bribe", "blackmail"];
  const mildConcern = ["exploit", "loophole", "bypass", "circumvent", "evade"];

  const severeMatches = severeIllegal.filter((w) => lowerText.includes(w));
  const moderateMatches = moderateIllegal.filter((w) => lowerText.includes(w));
  const mildMatches = mildConcern.filter((w) => lowerText.includes(w));

  if (severeMatches.length > 0) {
    score += 0.5 + 0.15 * severeMatches.length;
    details.push(`SEVERE: Criminal intent markers - ${severeMatches.join(", ")}`);
    reasoning.push({
      label: "Criminal Intent Detection",
      description: `The input contains ${severeMatches.length} severe criminal intent marker(s): "${severeMatches.join('", "')}". These terms directly reference violent crimes and are subject to mandatory reporting under most jurisdictions.`,
      impact: Math.min(0.5 + 0.15 * severeMatches.length, 1),
    });
    laws.push({
      code: "18-USC-875(c)",
      title: "US Code - Interstate Threats",
      description: "Transmitting any communication containing threats to injure another person is a federal crime punishable by up to 5 years imprisonment.",
      severity: "critical",
    });
    laws.push({
      code: "EU-DIR-2017/541",
      title: "EU Directive on Combating Terrorism",
      description: "Public provocation to commit a terrorist offence, including online, is criminalized across all EU member states.",
      severity: "critical",
    });
  }

  if (moderateMatches.length > 0) {
    score += 0.3 + 0.1 * moderateMatches.length;
    details.push(`MODERATE: Legal violation indicators - ${moderateMatches.join(", ")}`);
    reasoning.push({
      label: "Financial/Property Crime Indicators",
      description: `Detected ${moderateMatches.length} moderate legal violation term(s): "${moderateMatches.join('", "')}". These relate to financial crimes, property crimes, or unauthorized access that carry significant legal penalties.`,
      impact: Math.min(0.3 + 0.1 * moderateMatches.length, 1),
    });
    laws.push({
      code: "CFAA-18-USC-1030",
      title: "Computer Fraud and Abuse Act",
      description: "Unauthorized access to computer systems, data theft, and intentional damage to protected computers are federal offenses.",
      severity: "warning",
    });
  }

  if (mildMatches.length > 0) {
    score += 0.1 * mildMatches.length;
    details.push(`LOW: Potential compliance concerns - ${mildMatches.join(", ")}`);
    reasoning.push({
      label: "Regulatory Compliance Concern",
      description: `Found ${mildMatches.length} compliance-adjacent term(s): "${mildMatches.join('", "')}". While not inherently illegal, these suggest potential intent to circumvent rules or regulations that should be monitored.`,
      impact: Math.min(0.1 * mildMatches.length, 0.5),
    });
  }

  // Privacy violation check
  const privacyTerms = ["social security", "credit card", "ssn", "password", "pin number", "private data"];
  const privacyMatches = privacyTerms.filter((t) => lowerText.includes(t));
  if (privacyMatches.length > 0) {
    score += 0.2;
    details.push(`Privacy sensitivity: ${privacyMatches.join(", ")}`);
    reasoning.push({
      label: "Personal Data Exposure Risk",
      description: `The input references ${privacyMatches.length} sensitive data type(s): "${privacyMatches.join('", "')}". Handling or soliciting this data without consent violates multiple privacy frameworks.`,
      impact: 0.2,
    });
    laws.push({
      code: "GDPR-Art-9",
      title: "EU GDPR - Special Categories of Data",
      description: "Processing of sensitive personal data requires explicit consent and is subject to strict regulatory controls with fines up to 4% of global annual turnover.",
      severity: "critical",
    });
    laws.push({
      code: "CCPA-1798.100",
      title: "California Consumer Privacy Act",
      description: "Consumers have the right to know what personal data is collected, and businesses must implement reasonable security measures.",
      severity: "warning",
    });
  }

  // Ethical violation check
  const ethicalTerms = ["discriminate", "bias", "unfair", "exploit children", "slave"];
  const ethicalMatches = ethicalTerms.filter((t) => lowerText.includes(t));
  if (ethicalMatches.length > 0) {
    score += 0.3;
    details.push(`Ethical concerns: ${ethicalMatches.join(", ")}`);
    reasoning.push({
      label: "Ethical Violation Assessment",
      description: `Detected ${ethicalMatches.length} ethical concern(s): "${ethicalMatches.join('", "')}". These terms indicate potential human rights violations or systemic discrimination that are prohibited under international law.`,
      impact: 0.3,
    });
    laws.push({
      code: "UDHR-Art-1-2",
      title: "Universal Declaration of Human Rights",
      description: "All human beings are born free and equal in dignity and rights, without distinction of any kind.",
      severity: "critical",
    });
  }

  score = Math.max(0, Math.min(1, score));

  if (reasoning.length === 0) {
    reasoning.push({
      label: "Legal Compliance Verified",
      description: "The input text does not contain any indicators of criminal intent, privacy violations, or ethical concerns. All legal and regulatory compliance checks have been passed.",
      impact: 0,
    });
  }

  if (laws.length === 0) {
    laws.push({
      code: "BASELINE",
      title: "Standard Compliance Framework",
      description: "No specific legal or regulatory concerns identified. Standard content governance policies apply.",
      severity: "info",
    });
  }

  const recommendation =
    score > 0.6
      ? "Immediately escalate to legal review team. Do not process this request. Preserve all logs for potential regulatory reporting."
      : score > 0.3
        ? "Flag for compliance review. Apply enhanced monitoring and ensure all responses comply with applicable regulations."
        : "No legal concerns identified. Standard content policies are sufficient.";

  return {
    agent: "Legal Agent",
    category: "Legal & Ethics",
    score: Math.round(score * 100) / 100,
    message:
      score > 0.6
        ? "Significant legal/ethical concerns identified"
        : score > 0.3
          ? "Minor legal concerns flagged"
          : "Legal compliance verified",
    details,
    icon: "scale",
    reasoning,
    laws,
    recommendation,
  };
}

// ============================================
// Cyber Security Agent
// ============================================
function runCyberAgent(text: string): AgentResult {
  const lowerText = text.toLowerCase();
  const details: string[] = [];
  const reasoning: ReasoningItem[] = [];
  const laws: LawReference[] = [];
  let score = 0;

  const credentialTerms = ["password", "api key", "secret key", "token", "credentials", "private key"];
  const credMatches = credentialTerms.filter((t) => lowerText.includes(t));
  if (credMatches.length > 0) {
    score += 0.3 + 0.1 * credMatches.length;
    details.push(`Credential exposure risk: ${credMatches.join(", ")}`);
    reasoning.push({
      label: "Credential Exposure Analysis",
      description: `The input references ${credMatches.length} credential-related term(s): "${credMatches.join('", "')}". This may indicate credential harvesting, phishing preparation, or unintentional secrets exposure that could compromise system security.`,
      impact: Math.min(0.3 + 0.1 * credMatches.length, 1),
    });
    laws.push({
      code: "NIST-SP-800-63B",
      title: "NIST Digital Identity Guidelines",
      description: "Credential management and protection standards require secure handling of authentication secrets. Exposure of credentials constitutes a security incident.",
      severity: "warning",
    });
  }

  const injectionPatterns = ["select *", "drop table", "union select", "<script>", "eval(", "exec("];
  const injectionMatches = injectionPatterns.filter((p) => lowerText.includes(p));
  if (injectionMatches.length > 0) {
    score += 0.4 + 0.15 * injectionMatches.length;
    details.push(`Code injection pattern detected: ${injectionMatches.length} pattern(s)`);
    reasoning.push({
      label: "Injection Attack Vector",
      description: `Detected ${injectionMatches.length} code injection pattern(s) matching SQL injection, XSS, or remote code execution signatures. These patterns are commonly used in cyberattacks to compromise system integrity and extract data.`,
      impact: Math.min(0.4 + 0.15 * injectionMatches.length, 1),
    });
    laws.push({
      code: "CFAA-18-USC-1030",
      title: "Computer Fraud and Abuse Act",
      description: "Intentional unauthorized access or exceeding authorized access to a protected computer to obtain information is a federal crime.",
      severity: "critical",
    });
    laws.push({
      code: "OWASP-A03",
      title: "OWASP Top 10 - A03:2021 Injection",
      description: "Injection flaws, such as SQL and XSS, occur when untrusted data is sent to an interpreter as part of a command or query. The attacker's hostile data can trick the interpreter.",
      severity: "critical",
    });
  }

  const socialEngTerms = ["phishing", "impersonate", "pretend to be", "fake email", "spoof"];
  const socialMatches = socialEngTerms.filter((t) => lowerText.includes(t));
  if (socialMatches.length > 0) {
    score += 0.35;
    details.push(`Social engineering indicators: ${socialMatches.join(", ")}`);
    reasoning.push({
      label: "Social Engineering Threat",
      description: `Found ${socialMatches.length} social engineering indicator(s): "${socialMatches.join('", "')}". Social engineering is the most common initial attack vector, exploiting human trust to gain unauthorized access to systems or data.`,
      impact: 0.35,
    });
    laws.push({
      code: "CAN-SPAM-ACT",
      title: "CAN-SPAM Act / Anti-Phishing",
      description: "Deceptive email practices including spoofing and phishing are prohibited under federal anti-fraud statutes.",
      severity: "warning",
    });
  }

  const networkTerms = ["ddos", "brute force", "port scan", "man in the middle", "backdoor", "rootkit"];
  const networkMatches = networkTerms.filter((t) => lowerText.includes(t));
  if (networkMatches.length > 0) {
    score += 0.4;
    details.push(`Network attack references: ${networkMatches.join(", ")}`);
    reasoning.push({
      label: "Network Attack Intelligence",
      description: `Detected ${networkMatches.length} network attack reference(s): "${networkMatches.join('", "')}". These terms describe active cyber-warfare techniques that target infrastructure availability and integrity.`,
      impact: 0.4,
    });
    laws.push({
      code: "18-USC-1030(a)(5)",
      title: "US Code - Computer Damage",
      description: "Knowingly causing the transmission of a program or code that intentionally causes damage to a protected computer is a federal crime.",
      severity: "critical",
    });
  }

  const malwareTerms = ["malware", "ransomware", "trojan", "keylogger", "spyware", "worm"];
  const malwareMatches = malwareTerms.filter((t) => lowerText.includes(t));
  if (malwareMatches.length > 0) {
    score += 0.35;
    details.push(`Malware references: ${malwareMatches.join(", ")}`);
    reasoning.push({
      label: "Malware Threat Analysis",
      description: `Identified ${malwareMatches.length} malware-related term(s): "${malwareMatches.join('", "')}". References to malicious software may indicate intent to develop, distribute, or deploy harmful programs.`,
      impact: 0.35,
    });
    laws.push({
      code: "BUDAPEST-CONV-6",
      title: "Budapest Convention Art. 6 - Misuse of Devices",
      description: "Production, sale, or distribution of tools designed primarily for committing computer offenses is criminalized internationally.",
      severity: "critical",
    });
  }

  score = Math.max(0, Math.min(1, score));

  if (reasoning.length === 0) {
    reasoning.push({
      label: "Security Scan Clear",
      description: "No credential exposure, injection patterns, social engineering, network attack references, or malware indicators were detected. The input passes all cybersecurity checks.",
      impact: 0,
    });
  }

  if (laws.length === 0) {
    laws.push({
      code: "ISO-27001",
      title: "ISO 27001 - Information Security",
      description: "Standard information security management practices apply. No elevated security concerns identified.",
      severity: "info",
    });
  }

  const recommendation =
    score > 0.5
      ? "Critical security threat detected. Block request immediately, quarantine input, and alert security operations center."
      : score > 0.2
        ? "Security concerns noted. Apply input sanitization and enhanced logging before processing."
        : "Security profile is clean. Standard security measures are sufficient.";

  return {
    agent: "Cyber Security Agent",
    category: "Security Analysis",
    score: Math.round(score * 100) / 100,
    message:
      score > 0.5
        ? "Critical security risks identified"
        : score > 0.2
          ? "Minor security concerns noted"
          : "Security profile clean",
    details,
    icon: "shield",
    reasoning,
    laws,
    recommendation,
  };
}

// ============================================
// Bias & Fairness Agent
// ============================================
function runBiasAgent(text: string): AgentResult {
  const lowerText = text.toLowerCase();
  const details: string[] = [];
  const reasoning: ReasoningItem[] = [];
  const laws: LawReference[] = [];
  let score = 0;

  const biasTerms = ["only men", "only women", "all black", "all white", "all asians", "those people", "they always"];
  const biasMatches = biasTerms.filter((t) => lowerText.includes(t));
  if (biasMatches.length > 0) {
    score += 0.4 + 0.15 * biasMatches.length;
    details.push(`Stereotyping language detected: ${biasMatches.join(", ")}`);
    reasoning.push({
      label: "Stereotyping Language Detection",
      description: `Found ${biasMatches.length} stereotyping pattern(s): "${biasMatches.join('", "')}". These generalizations reinforce harmful stereotypes and can lead to discriminatory AI outputs that cause real-world harm to marginalized groups.`,
      impact: Math.min(0.4 + 0.15 * biasMatches.length, 1),
    });
    laws.push({
      code: "EU-AI-ACT-10",
      title: "EU AI Act - Data & Bias Governance",
      description: "Training data and AI inputs must be examined for biases. Systems must implement bias detection and mitigation measures.",
      severity: "critical",
    });
    laws.push({
      code: "TITLE-VII-CRA",
      title: "US Civil Rights Act - Title VII",
      description: "Prohibits discrimination based on race, color, religion, sex, or national origin in employment and related AI-assisted decisions.",
      severity: "critical",
    });
  }

  const exclusionTerms = ["exclude", "ban all", "no women", "no men", "restrict access"];
  const exclMatches = exclusionTerms.filter((t) => lowerText.includes(t));
  if (exclMatches.length > 0) {
    score += 0.3;
    details.push(`Exclusionary directives: ${exclMatches.join(", ")}`);
    reasoning.push({
      label: "Exclusionary Directive Analysis",
      description: `Detected ${exclMatches.length} exclusionary instruction(s): "${exclMatches.join('", "')}". These directives attempt to create discriminatory filters that would produce biased outputs violating equal treatment principles.`,
      impact: 0.3,
    });
    laws.push({
      code: "ECHR-Art-14",
      title: "European Convention on Human Rights - Art. 14",
      description: "Prohibits discrimination on any ground such as sex, race, colour, language, religion, or other status.",
      severity: "warning",
    });
  }

  const fairnessTerms = ["fair", "equal", "inclusive", "diverse", "balanced"];
  const fairMatches = fairnessTerms.filter((t) => lowerText.includes(t));
  if (fairMatches.length > 0) {
    score -= 0.15 * fairMatches.length;
    details.push(`Positive fairness indicators: ${fairMatches.join(", ")}`);
    reasoning.push({
      label: "Fairness Language Positive Signal",
      description: `Found ${fairMatches.length} positive fairness indicator(s): "${fairMatches.join('", "')}". These terms demonstrate awareness of equity principles and reduce the overall bias risk score.`,
      impact: 0,
    });
  }

  score = Math.max(0, Math.min(1, score));

  if (reasoning.length === 0) {
    reasoning.push({
      label: "Bias Audit Passed",
      description: "The input does not contain stereotyping language, exclusionary directives, or other bias indicators. The content meets fairness and equity standards for responsible AI processing.",
      impact: 0,
    });
  }

  if (laws.length === 0) {
    laws.push({
      code: "IEEE-7010",
      title: "IEEE 7010 - Wellbeing Metrics for AI",
      description: "Standard fairness and wellbeing metrics apply. No elevated bias concerns identified.",
      severity: "info",
    });
  }

  const recommendation =
    score > 0.4
      ? "Significant bias detected. Apply bias mitigation filters and ensure outputs are reviewed for discriminatory content before delivery."
      : score > 0.15
        ? "Minor bias indicators present. Standard fairness checks are recommended before generating responses."
        : "No bias concerns. Content is aligned with fairness and equity principles.";

  return {
    agent: "Bias & Fairness Agent",
    category: "Fairness Audit",
    score: Math.round(score * 100) / 100,
    message: score > 0.4 ? "Bias concerns identified" : "Fairness criteria met",
    details,
    icon: "balance",
    reasoning,
    laws,
    recommendation,
  };
}

// ============================================
// Misinformation Agent
// ============================================
function runMisinfoAgent(text: string): AgentResult {
  const lowerText = text.toLowerCase();
  const details: string[] = [];
  const reasoning: ReasoningItem[] = [];
  const laws: LawReference[] = [];
  let score = 0;

  const misinfoPatterns = [
    "fake news",
    "conspiracy",
    "cover up",
    "they dont want you to know",
    "hidden truth",
    "mainstream media lies",
    "big pharma",
    "flat earth",
  ];
  const misinfoMatches = misinfoPatterns.filter((p) => lowerText.includes(p));
  if (misinfoMatches.length > 0) {
    score += 0.35 + 0.15 * misinfoMatches.length;
    details.push(`Misinformation markers: ${misinfoMatches.join(", ")}`);
    reasoning.push({
      label: "Misinformation Pattern Recognition",
      description: `Detected ${misinfoMatches.length} known misinformation pattern(s): "${misinfoMatches.join('", "')}". These phrases are commonly associated with conspiracy theories and disinformation campaigns that can cause significant public harm.`,
      impact: Math.min(0.35 + 0.15 * misinfoMatches.length, 1),
    });
    laws.push({
      code: "DSA-Art-34",
      title: "EU Digital Services Act - Systemic Risks",
      description: "Platforms must assess and mitigate systemic risks from dissemination of disinformation and manipulation of their services.",
      severity: "critical",
    });
  }

  const absoluteTerms = ["always", "never", "everyone knows", "nobody", "100%", "guaranteed", "proven fact"];
  const absMatches = absoluteTerms.filter((t) => lowerText.includes(t));
  if (absMatches.length > 2) {
    score += 0.15;
    details.push("Excessive use of absolute language detected");
    reasoning.push({
      label: "Absolute Language Analysis",
      description: `Found ${absMatches.length} absolute terms exceeding threshold of 2: "${absMatches.join('", "')}". Overuse of absolute language is a hallmark of misinformation - legitimate claims typically use qualified, evidence-based language.`,
      impact: 0.15,
    });
    laws.push({
      code: "FTC-ACT-5",
      title: "FTC Act Section 5 - Deceptive Practices",
      description: "Unfair or deceptive acts or practices in commerce are unlawful. Absolute claims without evidence may constitute deceptive advertising.",
      severity: "warning",
    });
  }

  const sensationalTerms = ["shocking", "unbelievable", "mind-blowing", "you wont believe", "exposed"];
  const sensMatches = sensationalTerms.filter((t) => lowerText.includes(t));
  if (sensMatches.length > 0) {
    score += 0.2;
    details.push(`Sensationalist language: ${sensMatches.join(", ")}`);
    reasoning.push({
      label: "Sensationalism Assessment",
      description: `Identified ${sensMatches.length} sensationalist term(s): "${sensMatches.join('", "')}". Sensationalist language is designed to provoke emotional reactions rather than inform. This is a common tactic in clickbait and disinformation campaigns.`,
      impact: 0.2,
    });
  }

  score = Math.max(0, Math.min(1, score));

  if (reasoning.length === 0) {
    reasoning.push({
      label: "Information Credibility Verified",
      description: "No misinformation patterns, excessive absolute language, or sensationalist tactics detected. The input language is consistent with factual, evidence-based communication.",
      impact: 0,
    });
  }

  if (laws.length === 0) {
    laws.push({
      code: "IEEE-P7011",
      title: "IEEE P7011 - Standard for AI Truthfulness",
      description: "Standard truthfulness and transparency guidelines apply. No elevated misinformation concerns identified.",
      severity: "info",
    });
  }

  const recommendation =
    score > 0.4
      ? "High misinformation risk. Apply fact-checking filters, include disclaimers, and avoid amplifying unverified claims in any generated response."
      : score > 0.15
        ? "Some credibility concerns. Cross-reference claims with verified sources before generating a response."
        : "Information credibility is good. Standard content generation policies apply.";

  return {
    agent: "Misinformation Agent",
    category: "Truth Analysis",
    score: Math.round(score * 100) / 100,
    message: score > 0.4 ? "Potential misinformation detected" : "Information credibility check passed",
    details,
    icon: "search",
    reasoning,
    laws,
    recommendation,
  };
}

// ============================================
// Governance Core
// ============================================
function evaluate(text: string): EvaluationResult {
  const agents = [
    runPsychologyAgent(text),
    runNeuroscienceAgent(text),
    runLegalAgent(text),
    runCyberAgent(text),
    runBiasAgent(text),
    runMisinfoAgent(text),
  ];

  const avgScore = agents.reduce((sum, a) => sum + a.score, 0) / agents.length;
  const maxScore = Math.max(...agents.map((a) => a.score));

  let decision: EvaluationResult["decision"];
  if (avgScore > 0.55 || maxScore > 0.8) {
    decision = "BLOCKED";
  } else if (avgScore > 0.3 || maxScore > 0.5) {
    decision = "REVIEW_REQUIRED";
  } else {
    decision = "APPROVED";
  }

  const highRiskAgents = agents.filter((a) => a.score > 0.5).map((a) => a.category);
  let summary: string;
  if (decision === "BLOCKED") {
    summary = `Request blocked due to elevated risk across ${highRiskAgents.length} domain(s): ${highRiskAgents.join(", ")}. Overall threat level: ${(avgScore * 100).toFixed(0)}%.`;
  } else if (decision === "REVIEW_REQUIRED") {
    summary = `Manual review recommended. Moderate risk detected in: ${highRiskAgents.length > 0 ? highRiskAgents.join(", ") : "general assessment"}. Composite risk: ${(avgScore * 100).toFixed(0)}%.`;
  } else {
    summary = `Request approved. All governance checks passed with a composite risk score of ${(avgScore * 100).toFixed(0)}%. No significant concerns detected.`;
  }

  return {
    id: `eval_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`,
    timestamp: new Date().toISOString(),
    input: text,
    decision,
    overallScore: Math.round(avgScore * 100) / 100,
    agents,
    summary,
  };
}

// ============================================
// API Route Handler
// ============================================
export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { text } = body;

    if (!text || typeof text !== "string" || text.trim().length === 0) {
      return NextResponse.json({ error: "Please provide a valid text input for evaluation" }, { status: 400 });
    }

    if (text.length > 5000) {
      return NextResponse.json({ error: "Input exceeds maximum length of 5000 characters" }, { status: 400 });
    }

    const result = evaluate(text.trim());
    return NextResponse.json(result);
  } catch {
    return NextResponse.json({ error: "Internal server error during evaluation" }, { status: 500 });
  }
}
