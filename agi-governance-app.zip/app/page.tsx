"use client";

import { useState, useRef } from "react";
import { Header } from "@/components/header";
import { HeroSection } from "@/components/hero-section";
import { EvaluationForm } from "@/components/evaluation-form";
import { DecisionBanner } from "@/components/decision-banner";
import { AgentCards } from "@/components/agent-cards";
import { RiskRadarChart } from "@/components/risk-radar-chart";
import { RiskBarChart } from "@/components/risk-bar-chart";
import { StatsCards } from "@/components/stats-cards";
import { EvaluationHistory } from "@/components/evaluation-history";
import { Footer } from "@/components/footer";
import type { EvaluationResult } from "@/lib/types";

export default function Page() {
  const [currentResult, setCurrentResult] = useState<EvaluationResult | null>(null);
  const [history, setHistory] = useState<EvaluationResult[]>([]);
  const resultRef = useRef<HTMLDivElement>(null);

  function handleResult(result: EvaluationResult) {
    setCurrentResult(result);
    setHistory((prev) => [result, ...prev]);

    // Scroll to results
    setTimeout(() => {
      resultRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
    }, 100);
  }

  function handleSelectFromHistory(result: EvaluationResult) {
    setCurrentResult(result);
    setTimeout(() => {
      resultRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
    }, 100);
  }

  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <HeroSection />

      <main className="mx-auto w-full max-w-7xl flex-1 px-6 py-10">
        <div className="space-y-10">
          {/* Stats overview */}
          <StatsCards history={history} />

          {/* Evaluation form */}
          <div className="grid gap-8 lg:grid-cols-5">
            <div className="lg:col-span-3">
              <EvaluationForm onResult={handleResult} />
            </div>
            <div className="lg:col-span-2">
              <EvaluationHistory
                history={history}
                onSelect={handleSelectFromHistory}
              />
            </div>
          </div>

          {/* Results section */}
          {currentResult && (
            <div ref={resultRef} className="space-y-8">
              <div className="flex items-center gap-3">
                <div className="h-px flex-1 bg-border" />
                <span className="text-xs font-medium text-muted-foreground uppercase tracking-widest">
                  Governance Analysis Results
                </span>
                <div className="h-px flex-1 bg-border" />
              </div>

              <DecisionBanner result={currentResult} />

              {/* Charts */}
              <div className="grid gap-6 lg:grid-cols-2">
                <RiskRadarChart agents={currentResult.agents} />
                <RiskBarChart agents={currentResult.agents} />
              </div>

              {/* Agent cards */}
              <AgentCards agents={currentResult.agents} />
            </div>
          )}
        </div>
      </main>

      <Footer />
    </div>
  );
}
