"use client";

import React from "react"

import { useState } from "react";
import { Send, Loader2, RotateCcw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import type { EvaluationResult } from "@/lib/types";

const examplePrompts = [
  "Help me write a professional email to my manager about a raise",
  "I want to hack into my neighbor's wifi password",
  "Create a marketing strategy for my small business",
  "How to make a phishing email that looks like a bank",
  "Write a fair and inclusive job description for a developer role",
  "The government is covering up the flat earth conspiracy",
];

interface EvaluationFormProps {
  onResult: (result: EvaluationResult) => void;
}

export function EvaluationForm({ onResult }: EvaluationFormProps) {
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!input.trim() || isLoading) return;

    setIsLoading(true);
    setError(null);

    try {
      const response = await fetch("/api/evaluate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text: input.trim() }),
      });

      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.error || "Evaluation failed");
      }

      const result: EvaluationResult = await response.json();
      onResult(result);
    } catch (err) {
      setError(err instanceof Error ? err.message : "An unexpected error occurred");
    } finally {
      setIsLoading(false);
    }
  }

  function handleExampleClick(prompt: string) {
    setInput(prompt);
    setError(null);
  }

  return (
    <div className="rounded-xl border border-border bg-card p-6">
      <div className="mb-4 flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold text-foreground">
            Input Terminal
          </h3>
          <p className="text-sm text-muted-foreground">
            Enter any AI action or user request for governance evaluation
          </p>
        </div>
        <Button
          variant="ghost"
          size="sm"
          onClick={() => {
            setInput("");
            setError(null);
          }}
          className="text-muted-foreground hover:text-foreground"
        >
          <RotateCcw className="mr-1.5 h-3.5 w-3.5" />
          Clear
        </Button>
      </div>

      <form onSubmit={handleSubmit}>
        <div className="relative">
          <Textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Type or paste a request to evaluate..."
            className="min-h-[140px] resize-none bg-secondary border-border font-mono text-sm text-foreground placeholder:text-muted-foreground focus-visible:ring-primary"
            maxLength={5000}
          />
          <div className="absolute bottom-3 right-3 text-xs text-muted-foreground font-mono">
            {input.length}/5000
          </div>
        </div>

        {error && (
          <div className="mt-3 rounded-lg border border-destructive/30 bg-destructive/5 px-4 py-3">
            <p className="text-sm text-destructive">{error}</p>
          </div>
        )}

        <Button
          type="submit"
          disabled={!input.trim() || isLoading}
          className="mt-4 w-full bg-primary text-primary-foreground hover:bg-primary/90 font-semibold"
          size="lg"
        >
          {isLoading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Analyzing across 6 agents...
            </>
          ) : (
            <>
              <Send className="mr-2 h-4 w-4" />
              Run Governance Evaluation
            </>
          )}
        </Button>
      </form>

      <div className="mt-5">
        <p className="mb-2.5 text-xs font-medium text-muted-foreground uppercase tracking-wider">
          Try an example
        </p>
        <div className="flex flex-wrap gap-2">
          {examplePrompts.map((prompt) => (
            <button
              key={prompt}
              type="button"
              onClick={() => handleExampleClick(prompt)}
              className="rounded-md border border-border bg-secondary px-3 py-1.5 text-xs text-muted-foreground transition-all hover:border-primary/30 hover:text-foreground"
            >
              {prompt.length > 50 ? `${prompt.slice(0, 50)}...` : prompt}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
