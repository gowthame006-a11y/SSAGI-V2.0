"use client";

import { ShieldCheck, ShieldAlert, ShieldX } from "lucide-react";
import type { EvaluationResult } from "@/lib/types";

interface DecisionBannerProps {
  result: EvaluationResult;
}

const decisionConfig = {
  APPROVED: {
    icon: ShieldCheck,
    label: "APPROVED",
    description: "All governance checks passed",
    bgClass: "bg-[hsl(var(--success))]/5 border-[hsl(var(--success))]/30",
    textClass: "text-[hsl(var(--success))]",
    glowClass: "glow-teal",
    dotClass: "bg-[hsl(var(--success))]",
  },
  REVIEW_REQUIRED: {
    icon: ShieldAlert,
    label: "REVIEW REQUIRED",
    description: "Manual human review recommended",
    bgClass: "bg-[hsl(var(--warning))]/5 border-[hsl(var(--warning))]/30",
    textClass: "text-[hsl(var(--warning))]",
    glowClass: "glow-yellow",
    dotClass: "bg-[hsl(var(--warning))]",
  },
  BLOCKED: {
    icon: ShieldX,
    label: "BLOCKED",
    description: "Request denied by governance system",
    bgClass: "bg-destructive/5 border-destructive/30",
    textClass: "text-destructive",
    glowClass: "glow-red",
    dotClass: "bg-destructive",
  },
};

export function DecisionBanner({ result }: DecisionBannerProps) {
  const config = decisionConfig[result.decision];
  const Icon = config.icon;

  return (
    <div className={`rounded-xl border p-6 ${config.bgClass} ${config.glowClass}`}>
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div className="flex items-center gap-4">
          <div className="relative">
            <Icon className={`h-10 w-10 ${config.textClass}`} />
            <div className={`absolute -right-0.5 -top-0.5 h-3 w-3 rounded-full ${config.dotClass} animate-pulse-glow`} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className={`text-2xl font-bold font-mono ${config.textClass}`}>
                {config.label}
              </h3>
            </div>
            <p className="text-sm text-muted-foreground">{config.description}</p>
          </div>
        </div>

        <div className="flex items-center gap-6">
          <div className="text-center">
            <p className="text-xs text-muted-foreground uppercase tracking-wider mb-1">
              Risk Score
            </p>
            <p className={`text-3xl font-bold font-mono ${config.textClass}`}>
              {(result.overallScore * 100).toFixed(0)}%
            </p>
          </div>
          <div className="text-center">
            <p className="text-xs text-muted-foreground uppercase tracking-wider mb-1">
              Agents
            </p>
            <p className="text-3xl font-bold font-mono text-foreground">
              {result.agents.length}
            </p>
          </div>
        </div>
      </div>

      <div className="mt-4 rounded-lg bg-secondary/50 p-4">
        <p className="text-sm text-muted-foreground leading-relaxed font-mono">
          {result.summary}
        </p>
      </div>
    </div>
  );
}
