"use client";

import {
  Brain,
  Zap,
  Scale,
  Shield,
  BarChart3,
  Search,
} from "lucide-react";

const agents = [
  { name: "Psychology", icon: Brain, color: "text-primary" },
  { name: "Neuroscience", icon: Zap, color: "text-[hsl(var(--chart-2))]" },
  { name: "Legal", icon: Scale, color: "text-[hsl(var(--chart-4))]" },
  { name: "Cyber Security", icon: Shield, color: "text-[hsl(var(--chart-3))]" },
  { name: "Bias & Fairness", icon: BarChart3, color: "text-[hsl(var(--chart-5))]" },
  { name: "Misinformation", icon: Search, color: "text-[hsl(var(--warning))]" },
];

export function HeroSection() {
  return (
    <section className="relative overflow-hidden border-b border-border py-16 md:py-24">
      {/* Background grid */}
      <div className="pointer-events-none absolute inset-0 opacity-[0.03]">
        <div
          className="h-full w-full"
          style={{
            backgroundImage:
              "linear-gradient(hsl(175 70% 45%) 1px, transparent 1px), linear-gradient(90deg, hsl(175 70% 45%) 1px, transparent 1px)",
            backgroundSize: "60px 60px",
          }}
        />
      </div>

      <div className="relative mx-auto max-w-7xl px-6">
        <div className="mx-auto max-w-3xl text-center">
          <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-primary/20 bg-primary/5 px-4 py-1.5">
            <div className="h-1.5 w-1.5 rounded-full bg-primary animate-pulse-glow" />
            <span className="text-xs font-medium text-primary font-mono">
              HUMAN-ALIGNED AI GOVERNANCE
            </span>
          </div>

          <h2 className="mb-6 text-4xl font-bold tracking-tight text-foreground md:text-5xl lg:text-6xl text-balance">
            Multi-Agent{" "}
            <span className="text-primary">Risk Analysis</span>{" "}
            Engine
          </h2>

          <p className="mb-12 text-lg text-muted-foreground leading-relaxed text-pretty">
            Evaluate any AI action or user request through six specialized governance agents.
            Real-time analysis across psychology, neuroscience, legal compliance,
            cybersecurity, bias detection, and misinformation screening.
          </p>

          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-6">
            {agents.map((agent) => (
              <div
                key={agent.name}
                className="flex flex-col items-center gap-2 rounded-lg border border-border bg-card p-3 transition-all hover:border-primary/30 hover:bg-secondary"
              >
                <agent.icon className={`h-5 w-5 ${agent.color}`} />
                <span className="text-xs text-muted-foreground text-center">
                  {agent.name}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
