"use client";

import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Cell,
} from "recharts";
import type { AgentResult } from "@/lib/types";

interface RiskBarChartProps {
  agents: AgentResult[];
}

function getBarColor(score: number) {
  if (score > 0.6) return "hsl(0 72% 55%)";
  if (score > 0.3) return "hsl(45 90% 55%)";
  return "hsl(175 70% 45%)";
}

export function RiskBarChart({ agents }: RiskBarChartProps) {
  const data = agents.map((a) => ({
    name: a.category.split(" ")[0],
    fullName: a.agent,
    risk: Math.round(a.score * 100),
    score: a.score,
  }));

  return (
    <div className="rounded-xl border border-border bg-card p-6">
      <h3 className="mb-1 text-lg font-semibold text-foreground">
        Agent Risk Levels
      </h3>
      <p className="mb-4 text-sm text-muted-foreground">
        Comparative risk assessment across all agents
      </p>
      <div className="h-[320px] w-full">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data} barCategoryGap="20%">
            <CartesianGrid stroke="hsl(225 12% 16%)" strokeDasharray="3 3" vertical={false} />
            <XAxis
              dataKey="name"
              tick={{ fill: "hsl(220 10% 50%)", fontSize: 11 }}
              axisLine={{ stroke: "hsl(225 12% 16%)" }}
              tickLine={false}
            />
            <YAxis
              domain={[0, 100]}
              tick={{ fill: "hsl(220 10% 40%)", fontSize: 10 }}
              axisLine={{ stroke: "hsl(225 12% 16%)" }}
              tickLine={false}
              tickFormatter={(v) => `${v}%`}
            />
            <Tooltip
              contentStyle={{
                backgroundColor: "hsl(225 15% 9%)",
                border: "1px solid hsl(225 12% 20%)",
                borderRadius: "8px",
                color: "hsl(210 20% 95%)",
                fontSize: "12px",
              }}
              formatter={(value: number, _name: string, entry: { payload: { fullName: string } }) => [
                `${value}%`,
                entry.payload.fullName,
              ]}
              cursor={{ fill: "hsl(225 12% 12%)" }}
            />
            <Bar dataKey="risk" radius={[6, 6, 0, 0]}>
              {data.map((entry, index) => (
                <Cell key={index} fill={getBarColor(entry.score)} />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
