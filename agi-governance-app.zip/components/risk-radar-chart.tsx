"use client";

import {
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
  ResponsiveContainer,
  Tooltip,
} from "recharts";
import type { AgentResult } from "@/lib/types";

interface RiskRadarChartProps {
  agents: AgentResult[];
}

export function RiskRadarChart({ agents }: RiskRadarChartProps) {
  const data = agents.map((a) => ({
    subject: a.category.split(" ")[0],
    fullName: a.category,
    risk: Math.round(a.score * 100),
  }));

  return (
    <div className="rounded-xl border border-border bg-card p-6">
      <h3 className="mb-1 text-lg font-semibold text-foreground">
        Risk Distribution Radar
      </h3>
      <p className="mb-4 text-sm text-muted-foreground">
        Multi-dimensional threat visualization
      </p>
      <div className="h-[320px] w-full">
        <ResponsiveContainer width="100%" height="100%">
          <RadarChart cx="50%" cy="50%" outerRadius="70%" data={data}>
            <PolarGrid stroke="hsl(225 12% 20%)" />
            <PolarAngleAxis
              dataKey="subject"
              tick={{ fill: "hsl(220 10% 50%)", fontSize: 11 }}
            />
            <PolarRadiusAxis
              angle={90}
              domain={[0, 100]}
              tick={{ fill: "hsl(220 10% 40%)", fontSize: 10 }}
              tickCount={5}
            />
            <Tooltip
              contentStyle={{
                backgroundColor: "hsl(225 15% 9%)",
                border: "1px solid hsl(225 12% 20%)",
                borderRadius: "8px",
                color: "hsl(210 20% 95%)",
                fontSize: "12px",
              }}
              formatter={(value: number, _name: string, entry: { payload: { fullName: string } }) => [
                `${value}%`,
                entry.payload.fullName,
              ]}
            />
            <Radar
              name="Risk"
              dataKey="risk"
              stroke="hsl(175 70% 45%)"
              fill="hsl(175 70% 45%)"
              fillOpacity={0.2}
              strokeWidth={2}
            />
          </RadarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
