"use client";

import { Brain } from "lucide-react";

export function Footer() {
  return (
    <footer className="border-t border-border bg-card/50">
      <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-4 px-6 py-8 md:flex-row">
        <div className="flex items-center gap-2">
          <Brain className="h-4 w-4 text-primary" />
          <span className="text-sm text-muted-foreground">
            Synthetic Superego AGI
          </span>
          <span className="text-xs text-muted-foreground/50">
            Software-Only Governance Prototype
          </span>
        </div>
        <div className="flex items-center gap-6">
          <span className="text-xs text-muted-foreground font-mono">
            v3.0.0
          </span>
          <span className="text-xs text-muted-foreground">
            6 Active Agents
          </span>
          <span className="text-xs text-muted-foreground">
            Human-Aligned AI Governance
          </span>
        </div>
      </div>
    </footer>
  );
}
