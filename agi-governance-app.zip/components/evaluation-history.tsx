"use client";

import { Clock, ShieldCheck, ShieldAlert, ShieldX, ChevronRight } from "lucide-react";
import type { EvaluationResult } from "@/lib/types";

interface EvaluationHistoryProps {
  history: EvaluationResult[];
  onSelect: (result: EvaluationResult) => void;
}

const decisionIcons = {
  APPROVED: ShieldCheck,
  REVIEW_REQUIRED: ShieldAlert,
  BLOCKED: ShieldX,
};

const decisionColors = {
  APPROVED: "text-[hsl(var(--success))]",
  REVIEW_REQUIRED: "text-[hsl(var(--warning))]",
  BLOCKED: "text-destructive",
};

const decisionBg = {
  APPROVED: "bg-[hsl(var(--success))]/10",
  REVIEW_REQUIRED: "bg-[hsl(var(--warning))]/10",
  BLOCKED: "bg-destructive/10",
};

const decisionLabels = {
  APPROVED: "Approved",
  REVIEW_REQUIRED: "Review",
  BLOCKED: "Blocked",
};

export function EvaluationHistory({ history, onSelect }: EvaluationHistoryProps) {
  if (history.length === 0) {
    return (
      <div className="rounded-xl border border-border bg-card p-8 text-center">
        <Clock className="mx-auto mb-3 h-10 w-10 text-muted-foreground/30" />
        <h3 className="text-sm font-semibold text-foreground mb-1">
          No Evaluations Yet
        </h3>
        <p className="text-xs text-muted-foreground">
          Submit a request above to start analyzing
        </p>
      </div>
    );
  }

  return (
    <div className="rounded-xl border border-border bg-card">
      <div className="flex items-center justify-between border-b border-border px-6 py-4">
        <div>
          <h3 className="text-lg font-semibold text-foreground">
            Evaluation History
          </h3>
          <p className="text-sm text-muted-foreground">
            {history.length} evaluation{history.length !== 1 ? "s" : ""} this session
          </p>
        </div>
        <div className="flex gap-3">
          <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
            <div className="h-2 w-2 rounded-full bg-[hsl(var(--success))]" />
            {history.filter((h) => h.decision === "APPROVED").length} approved
          </div>
          <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
            <div className="h-2 w-2 rounded-full bg-[hsl(var(--warning))]" />
            {history.filter((h) => h.decision === "REVIEW_REQUIRED").length} review
          </div>
          <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
            <div className="h-2 w-2 rounded-full bg-destructive" />
            {history.filter((h) => h.decision === "BLOCKED").length} blocked
          </div>
        </div>
      </div>

      <div className="divide-y divide-border">
        {history.map((item) => {
          const Icon = decisionIcons[item.decision];
          return (
            <button
              type="button"
              key={item.id}
              onClick={() => onSelect(item)}
              className="flex w-full items-center gap-4 px-6 py-4 text-left transition-colors hover:bg-secondary/50"
            >
              <div className={`flex h-9 w-9 flex-shrink-0 items-center justify-center rounded-lg ${decisionBg[item.decision]}`}>
                <Icon className={`h-4.5 w-4.5 ${decisionColors[item.decision]}`} />
              </div>
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm text-foreground">
                  {item.input.length > 80 ? `${item.input.slice(0, 80)}...` : item.input}
                </p>
                <div className="mt-1 flex items-center gap-3">
                  <span className={`text-xs font-medium ${decisionColors[item.decision]}`}>
                    {decisionLabels[item.decision]}
                  </span>
                  <span className="text-xs text-muted-foreground font-mono">
                    Risk: {(item.overallScore * 100).toFixed(0)}%
                  </span>
                  <span className="text-xs text-muted-foreground">
                    {new Date(item.timestamp).toLocaleTimeString()}
                  </span>
                </div>
              </div>
              <ChevronRight className="h-4 w-4 flex-shrink-0 text-muted-foreground" />
            </button>
          );
        })}
      </div>
    </div>
  );
}
