"use client";

import { Activity, ShieldCheck, ShieldAlert, ShieldX } from "lucide-react";
import type { EvaluationResult } from "@/lib/types";

interface StatsCardsProps {
  history: EvaluationResult[];
}

export function StatsCards({ history }: StatsCardsProps) {
  const total = history.length;
  const approved = history.filter((h) => h.decision === "APPROVED").length;
  const review = history.filter((h) => h.decision === "REVIEW_REQUIRED").length;
  const blocked = history.filter((h) => h.decision === "BLOCKED").length;
  const avgRisk =
    total > 0
      ? history.reduce((sum, h) => sum + h.overallScore, 0) / total
      : 0;

  const stats = [
    {
      label: "Total Evaluations",
      value: total.toString(),
      icon: Activity,
      color: "text-primary",
      bg: "bg-primary/10",
    },
    {
      label: "Approved",
      value: approved.toString(),
      icon: ShieldCheck,
      color: "text-[hsl(var(--success))]",
      bg: "bg-[hsl(var(--success))]/10",
    },
    {
      label: "Under Review",
      value: review.toString(),
      icon: ShieldAlert,
      color: "text-[hsl(var(--warning))]",
      bg: "bg-[hsl(var(--warning))]/10",
    },
    {
      label: "Blocked",
      value: blocked.toString(),
      icon: ShieldX,
      color: "text-destructive",
      bg: "bg-destructive/10",
    },
  ];

  return (
    <div className="grid gap-4 grid-cols-2 lg:grid-cols-4">
      {stats.map((stat) => (
        <div
          key={stat.label}
          className="rounded-xl border border-border bg-card p-5"
        >
          <div className="flex items-center justify-between mb-3">
            <div className={`flex h-9 w-9 items-center justify-center rounded-lg ${stat.bg}`}>
              <stat.icon className={`h-4.5 w-4.5 ${stat.color}`} />
            </div>
            {stat.label === "Total Evaluations" && total > 0 && (
              <span className="text-xs text-muted-foreground font-mono">
                avg risk: {(avgRisk * 100).toFixed(0)}%
              </span>
            )}
          </div>
          <p className="text-2xl font-bold text-foreground font-mono">
            {stat.value}
          </p>
          <p className="text-xs text-muted-foreground mt-1">{stat.label}</p>
        </div>
      ))}
    </div>
  );
}
