"use client";

import React from "react"

import { useState } from "react";
import {
  Brain,
  Zap,
  Scale,
  Shield,
  BarChart3,
  Search,
  ChevronDown,
  ChevronUp,
  AlertTriangle,
  BookOpen,
  Lightbulb,
  FileText,
} from "lucide-react";
import type { AgentResult, LawReference, ReasoningItem } from "@/lib/types";

const iconMap: Record<string, React.ElementType> = {
  brain: Brain,
  zap: Zap,
  scale: Scale,
  shield: Shield,
  balance: BarChart3,
  search: Search,
};

const colorMap: Record<string, { text: string; bg: string; border: string; glow: string }> = {
  brain: {
    text: "text-primary",
    bg: "bg-primary/10",
    border: "border-primary/30",
    glow: "glow-teal",
  },
  zap: {
    text: "text-[hsl(var(--chart-2))]",
    bg: "bg-[hsl(var(--chart-2))]/10",
    border: "border-[hsl(var(--chart-2))]/30",
    glow: "glow-yellow",
  },
  scale: {
    text: "text-[hsl(var(--chart-4))]",
    bg: "bg-[hsl(var(--chart-4))]/10",
    border: "border-[hsl(var(--chart-4))]/30",
    glow: "",
  },
  shield: {
    text: "text-[hsl(var(--chart-3))]",
    bg: "bg-[hsl(var(--chart-3))]/10",
    border: "border-[hsl(var(--chart-3))]/30",
    glow: "glow-red",
  },
  balance: {
    text: "text-[hsl(var(--chart-5))]",
    bg: "bg-[hsl(var(--chart-5))]/10",
    border: "border-[hsl(var(--chart-5))]/30",
    glow: "",
  },
  search: {
    text: "text-[hsl(var(--warning))]",
    bg: "bg-[hsl(var(--warning))]/10",
    border: "border-[hsl(var(--warning))]/30",
    glow: "glow-yellow",
  },
};

function getScoreColor(score: number) {
  if (score > 0.6) return "text-destructive";
  if (score > 0.3) return "text-[hsl(var(--warning))]";
  return "text-[hsl(var(--success))]";
}

function getScoreBarColor(score: number) {
  if (score > 0.6) return "bg-destructive";
  if (score > 0.3) return "bg-[hsl(var(--warning))]";
  return "bg-[hsl(var(--success))]";
}

function getImpactBarColor(impact: number) {
  if (impact > 0.5) return "bg-destructive/80";
  if (impact > 0.2) return "bg-[hsl(var(--warning))]/80";
  return "bg-[hsl(var(--success))]/80";
}

function getSeverityStyle(severity: LawReference["severity"]) {
  switch (severity) {
    case "critical":
      return {
        bg: "bg-destructive/10",
        text: "text-destructive",
        border: "border-destructive/30",
        badge: "bg-destructive/20 text-destructive",
      };
    case "warning":
      return {
        bg: "bg-[hsl(var(--warning))]/10",
        text: "text-[hsl(var(--warning))]",
        border: "border-[hsl(var(--warning))]/30",
        badge: "bg-[hsl(var(--warning))]/20 text-[hsl(var(--warning))]",
      };
    case "info":
    default:
      return {
        bg: "bg-secondary",
        text: "text-muted-foreground",
        border: "border-border",
        badge: "bg-secondary text-muted-foreground",
      };
  }
}

function ReasoningSection({ reasoning }: { reasoning: ReasoningItem[] }) {
  return (
    <div className="space-y-3">
      <div className="flex items-center gap-2">
        <Lightbulb className="h-4 w-4 text-[hsl(var(--chart-2))]" />
        <h5 className="text-xs font-semibold uppercase tracking-wider text-[hsl(var(--chart-2))]">
          Analysis Reasoning
        </h5>
      </div>
      <div className="space-y-3">
        {reasoning.map((item, i) => (
          <div key={i} className="rounded-lg border border-border bg-secondary/30 p-3">
            <div className="flex items-start justify-between gap-3 mb-2">
              <h6 className="text-sm font-semibold text-foreground">{item.label}</h6>
              <div className="flex items-center gap-2 flex-shrink-0">
                <span className={`text-xs font-mono font-bold ${item.impact > 0.5 ? "text-destructive" : item.impact > 0.2 ? "text-[hsl(var(--warning))]" : "text-[hsl(var(--success))]"}`}>
                  {item.impact > 0 ? `+${(item.impact * 100).toFixed(0)}%` : "0%"}
                </span>
              </div>
            </div>
            {/* impact micro-bar */}
            <div className="mb-2 h-1 w-full overflow-hidden rounded-full bg-secondary">
              <div
                className={`h-full rounded-full transition-all duration-500 ${getImpactBarColor(item.impact)}`}
                style={{ width: `${Math.max(item.impact * 100, 1)}%` }}
              />
            </div>
            <p className="text-xs text-muted-foreground leading-relaxed">
              {item.description}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
}

function LawsSection({ laws }: { laws: LawReference[] }) {
  return (
    <div className="space-y-3">
      <div className="flex items-center gap-2">
        <BookOpen className="h-4 w-4 text-[hsl(var(--chart-4))]" />
        <h5 className="text-xs font-semibold uppercase tracking-wider text-[hsl(var(--chart-4))]">
          Applicable Laws & Regulations
        </h5>
      </div>
      <div className="space-y-2">
        {laws.map((law, i) => {
          const style = getSeverityStyle(law.severity);
          return (
            <div key={i} className={`rounded-lg border p-3 ${style.bg} ${style.border}`}>
              <div className="flex items-start justify-between gap-2 mb-1.5">
                <div className="flex items-center gap-2">
                  <FileText className={`h-3.5 w-3.5 flex-shrink-0 ${style.text}`} />
                  <span className={`text-xs font-mono font-bold ${style.text}`}>
                    {law.code}
                  </span>
                </div>
                <span className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full ${style.badge}`}>
                  {law.severity}
                </span>
              </div>
              <h6 className="text-sm font-semibold text-foreground mb-1">
                {law.title}
              </h6>
              <p className="text-xs text-muted-foreground leading-relaxed">
                {law.description}
              </p>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function RecommendationSection({ recommendation, score }: { recommendation: string; score: number }) {
  return (
    <div className="space-y-2">
      <div className="flex items-center gap-2">
        <AlertTriangle className={`h-4 w-4 ${score > 0.5 ? "text-destructive" : score > 0.2 ? "text-[hsl(var(--warning))]" : "text-[hsl(var(--success))]"}`} />
        <h5 className={`text-xs font-semibold uppercase tracking-wider ${score > 0.5 ? "text-destructive" : score > 0.2 ? "text-[hsl(var(--warning))]" : "text-[hsl(var(--success))]"}`}>
          Recommendation
        </h5>
      </div>
      <div className={`rounded-lg border p-3 ${score > 0.5 ? "bg-destructive/5 border-destructive/20" : score > 0.2 ? "bg-[hsl(var(--warning))]/5 border-[hsl(var(--warning))]/20" : "bg-[hsl(var(--success))]/5 border-[hsl(var(--success))]/20"}`}>
        <p className="text-sm text-foreground leading-relaxed">
          {recommendation}
        </p>
      </div>
    </div>
  );
}

function AgentCard({ agent }: { agent: AgentResult }) {
  const [expanded, setExpanded] = useState(true);
  const Icon = iconMap[agent.icon] || Brain;
  const colors = colorMap[agent.icon] || colorMap.brain;

  return (
    <div className={`rounded-xl border bg-card overflow-hidden transition-all ${colors.border} ${agent.score > 0.5 ? colors.glow : ""}`}>
      {/* Header */}
      <div className="p-5">
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className={`flex h-12 w-12 items-center justify-center rounded-xl ${colors.bg}`}>
              <Icon className={`h-6 w-6 ${colors.text}`} />
            </div>
            <div>
              <h4 className="text-base font-bold text-foreground">{agent.agent}</h4>
              <p className="text-xs text-muted-foreground font-mono">{agent.category}</p>
            </div>
          </div>
          <div className="text-right">
            <p className={`text-3xl font-bold font-mono ${getScoreColor(agent.score)}`}>
              {(agent.score * 100).toFixed(0)}
              <span className="text-sm">%</span>
            </p>
            <p className="text-[10px] uppercase tracking-widest text-muted-foreground">risk score</p>
          </div>
        </div>

        {/* Score bar */}
        <div className="mb-3 h-2 w-full overflow-hidden rounded-full bg-secondary">
          <div
            className={`h-full rounded-full transition-all duration-700 ${getScoreBarColor(agent.score)}`}
            style={{ width: `${Math.max(agent.score * 100, 2)}%` }}
          />
        </div>

        {/* Status message */}
        <div className={`rounded-lg px-3 py-2 mb-4 ${agent.score > 0.5 ? "bg-destructive/10" : agent.score > 0.2 ? "bg-[hsl(var(--warning))]/10" : "bg-[hsl(var(--success))]/10"}`}>
          <p className={`text-sm font-medium ${getScoreColor(agent.score)}`}>
            {agent.message}
          </p>
        </div>

        {/* Expand/Collapse */}
        <button
          type="button"
          onClick={() => setExpanded(!expanded)}
          className="flex items-center gap-1.5 text-xs font-semibold text-primary hover:text-primary/80 transition-colors"
        >
          {expanded ? (
            <>
              <ChevronUp className="h-3.5 w-3.5" />
              Collapse Full Report
            </>
          ) : (
            <>
              <ChevronDown className="h-3.5 w-3.5" />
              Expand Full Report
            </>
          )}
        </button>
      </div>

      {/* Expanded sections */}
      {expanded && (
        <div className="border-t border-border bg-secondary/20 p-5 space-y-5">
          {/* Reasoning */}
          <ReasoningSection reasoning={agent.reasoning} />

          {/* Separator */}
          <div className="h-px w-full bg-border" />

          {/* Laws & Regulations */}
          <LawsSection laws={agent.laws} />

          {/* Separator */}
          <div className="h-px w-full bg-border" />

          {/* Recommendation */}
          <RecommendationSection recommendation={agent.recommendation} score={agent.score} />
        </div>
      )}
    </div>
  );
}

interface AgentCardsProps {
  agents: AgentResult[];
}

export function AgentCards({ agents }: AgentCardsProps) {
  return (
    <div>
      <div className="mb-6 flex items-center gap-3">
        <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/10">
          <Shield className="h-4 w-4 text-primary" />
        </div>
        <div>
          <h3 className="text-lg font-bold text-foreground">
            Agent Analysis Breakdown
          </h3>
          <p className="text-xs text-muted-foreground">
            Detailed reasoning, applicable laws, and recommendations from each governance agent
          </p>
        </div>
      </div>
      <div className="grid gap-6 lg:grid-cols-2">
        {agents.map((agent) => (
          <AgentCard key={agent.agent} agent={agent} />
        ))}
      </div>
    </div>
  );
}
